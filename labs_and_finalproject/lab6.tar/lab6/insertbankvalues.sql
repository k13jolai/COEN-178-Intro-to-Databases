INSERT INTO bankcust_6 VALUES('1','Jim','Campbell','SJ');
INSERT INTO bankcust_6 VALUES('2','Janice','El Camino Real','SJ');
INSERT INTO bankcust_6 VALUES('3','Joe','Alameada','SJ');
INSERT INTO bankcust_6 VALUES('4','Jay','Franklin','SJ');
INSERT INTO bankcust_6 VALUES('5','Jordan','Sakura dr.','SJ');
INSERT INTO bankcust_6 VALUES('6','John','Stoneridge','SJ');
INSERT INTO bankcust_6 VALUES('7','Jane','Campbell','SJ');
