SELECT * FROM mycourses;
SELECT courseNO FROM mycourses WHERE units=4; 
SELECT courseNO FROM mycourses WHERE  grade='A';
SELECT courseNO,units FROM mycourses WHERE grade='C'; 

