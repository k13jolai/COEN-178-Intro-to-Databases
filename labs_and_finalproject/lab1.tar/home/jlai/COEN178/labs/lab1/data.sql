INSERT INTO test VALUES(10,'ten');
INSERT INTO test VALUES(11,'eleven');
